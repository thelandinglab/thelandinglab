/**
 * CARDÁPIO DIGITAL — ligação entre o painel e a planilha
 * Cole este código em Extensões > Apps Script da planilha do cliente.
 * Troque a senha abaixo antes de publicar.
 */
const SENHA = "troque-esta-senha";

const ABA_LOJA = "Loja";
const ABA_CATEGORIAS = "Categorias";
const ABA_ITENS = "Itens";
const CACHE_CHAVE = "cardapio_json";

function doGet() {
  const cache = CacheService.getScriptCache();
  const salvo = cache.get(CACHE_CHAVE);
  if (salvo) return json_(salvo, true);
  const dados = ler_();
  const texto = JSON.stringify(dados);
  if (texto.length < 95000) cache.put(CACHE_CHAVE, texto, 21600);
  return json_(texto, true);
}

function doPost(e) {
  let corpo = {};
  try { corpo = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, erro: "Pedido inválido." }); }
  if (corpo.senha !== SENHA) return json_({ ok: false, erro: "Senha incorreta." });
  if (corpo.acao === "entrar") return json_({ ok: true });
  if (corpo.acao === "salvar") {
    const lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      gravar_(corpo.dados);
      CacheService.getScriptCache().remove(CACHE_CHAVE);
      return json_({ ok: true });
    } catch (err) {
      return json_({ ok: false, erro: "Erro ao salvar: " + err.message });
    } finally { lock.releaseLock(); }
  }
  return json_({ ok: false, erro: "Ação desconhecida." });
}

/* ---------- leitura ---------- */
function ler_() {
  const ss = SpreadsheetApp.getActive();
  const lojaAba = ss.getSheetByName(ABA_LOJA);
  if (!lojaAba || lojaAba.getLastRow() < 2) return { vazio: true };
  const loja = {};
  lojaAba.getRange(2, 1, lojaAba.getLastRow() - 1, 2).getValues().forEach(function (r) {
    if (r[0]) { try { loja[r[0]] = JSON.parse(r[1]); } catch (e) { loja[r[0]] = r[1]; } }
  });
  const categorias = linhas_(ss.getSheetByName(ABA_CATEGORIAS)).map(function (r) {
    return { id: String(r.id), nome: r.nome, oculta: r.oculta === true || r.oculta === "SIM", ordem: Number(r.ordem) || 0 };
  });
  const itens = linhas_(ss.getSheetByName(ABA_ITENS)).map(function (r) {
    let ad = [];
    try { ad = r.adicionais ? JSON.parse(r.adicionais) : []; } catch (e) {}
    return {
      id: String(r.id), catId: String(r.categoria), nome: r.nome, descricao: r.descricao,
      preco: r.preco === "" ? null : Number(r.preco), foto: r.foto,
      etiqueta: r.etiqueta || "", tags: parseJson_(r.tags),
      esgotado: r.esgotado === true || r.esgotado === "SIM",
      destaque: r.destaque === true || r.destaque === "SIM",
      adicionais: ad, ordem: Number(r.ordem) || 0
    };
  });
  return { loja: loja, categorias: categorias, itens: itens };
}

function parseJson_(t) { try { return t ? JSON.parse(t) : []; } catch (e) { return []; } }

function linhas_(aba) {
  if (!aba || aba.getLastRow() < 2) return [];
  const v = aba.getDataRange().getValues();
  const cab = v.shift();
  return v.filter(function (r) { return r[0] !== ""; }).map(function (r) {
    const o = {}; cab.forEach(function (c, i) { o[c] = r[i]; }); return o;
  });
}

/* ---------- gravação ---------- */
function gravar_(d) {
  const ss = SpreadsheetApp.getActive();
  const loja = Object.keys(d.loja).map(function (k) { return [k, JSON.stringify(d.loja[k])]; });
  escrever_(ss, ABA_LOJA, ["chave", "valor"], loja);
  escrever_(ss, ABA_CATEGORIAS, ["id", "nome", "oculta", "ordem"],
    d.categorias.map(function (c, i) { return [c.id, c.nome, c.oculta ? "SIM" : "NÃO", i]; }));
  escrever_(ss, ABA_ITENS, ["id", "categoria", "nome", "descricao", "preco", "foto", "esgotado", "destaque", "adicionais", "ordem", "tags", "etiqueta"],
    d.itens.map(function (it, i) {
      return [it.id, it.catId, it.nome, it.descricao || "", it.preco == null ? "" : it.preco, it.foto || "",
        it.esgotado ? "SIM" : "NÃO", it.destaque ? "SIM" : "NÃO", JSON.stringify(it.adicionais || []), i, JSON.stringify(it.tags || []), it.etiqueta || ""];
    }));
}

function escrever_(ss, nome, cab, linhas) {
  const aba = ss.getSheetByName(nome) || ss.insertSheet(nome);
  aba.clearContents();
  aba.getRange(1, 1, 1, cab.length).setValues([cab]).setFontWeight("bold");
  if (linhas.length) aba.getRange(2, 1, linhas.length, cab.length).setValues(linhas);
  aba.setFrozenRows(1);
}

function json_(obj, jaTexto) {
  return ContentService.createTextOutput(jaTexto ? obj : JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
